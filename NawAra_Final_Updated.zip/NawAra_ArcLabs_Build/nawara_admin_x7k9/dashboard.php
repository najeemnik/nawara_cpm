<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_samesite', 'Strict');
session_start();

if (empty($_SESSION['admin_logged_in'])) { header('Location: index.php'); exit; }
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');

$csrf = $_SESSION['csrf_token'];
$dataFile = __DIR__ . '/../data/data.json';
$settingsFile = __DIR__ . '/../data/settings.json';
$adminFile = __DIR__ . '/../data/admin.json';

$data = file_exists($dataFile) ? json_decode(file_get_contents($dataFile), true) : ['projects'=>[],'news'=>[],'about'=>[],'contact'=>[]];
if (!$data) $data = ['projects'=>[],'news'=>[],'about'=>[],'contact'=>[]];
$settings = file_exists($settingsFile) ? json_decode(file_get_contents($settingsFile), true) : [];
if (!$settings) $settings = [];
$adminInfo = file_exists($adminFile) ? json_decode(file_get_contents($adminFile), true) : ['username'=>'nawara_admin'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NawAra Studio - Dashboard</title>
<meta name="robots" content="noindex, nofollow">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
:root { --bg: #0a0a0a; --bg2: #141414; --bg3: #1a1a1a; --text: #fff; --muted: #a0a0a0; --accent: #c9a961; --border: rgba(255,255,255,0.08); --danger: #ff5252; --success: #4caf50; --draft: #f39c12; --info: #3498db; }
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Vazirmatn', 'Inter', sans-serif; background: var(--bg); color: var(--text); min-height:100vh; }
.sidebar { position: fixed; top: 0; right: 0; width: 260px; height: 100vh; background: var(--bg2); border-left: 1px solid var(--border); padding: 25px 15px; overflow-y: auto; z-index: 50; }
.sb-logo { display:flex; align-items:center; gap:12px; padding:0 10px 20px; border-bottom:1px solid var(--border); margin-bottom:20px; }
.sb-logo .mark { width:40px; height:40px; background:linear-gradient(135deg,var(--accent),#8b7340); border-radius:8px; display:flex; align-items:center; justify-content:center; color:var(--bg); font-weight:700; font-size:18px; font-family:'Inter'; }
.sb-logo h2 { font-size:15px; } .sb-logo p { font-size:10px; color:var(--muted); letter-spacing:2px; }
.nav-item { display:flex; align-items:center; gap:12px; padding: 13px 15px; border-radius: 10px; color: var(--muted); cursor: pointer; margin-bottom: 5px; transition: all 0.2s; font-size: 14px; }
.nav-item:hover { background: rgba(255,255,255,0.04); color: white; }
.nav-item.active { background: rgba(201,169,97,0.12); color: var(--accent); }
.logout { margin-top: 30px; padding: 12px; background: rgba(255,82,82,0.1); border: 1px solid rgba(255,82,82,0.3); color: var(--danger); border-radius: 10px; text-align: center; text-decoration: none; display: block; font-size: 13px; }
.logout:hover { background: var(--danger); color: white; }
.main { margin-right: 260px; padding: 30px; }
.page-header { display: flex; justify-content: space-between; align-items: center; padding-bottom: 20px; margin-bottom: 25px; border-bottom: 1px solid var(--border); }
.page-header h1 { font-size: 26px; font-weight: 500; }
.page-header .sub { color: var(--muted); font-size: 13px; margin-top: 4px; }
.btn { padding: 11px 22px; border-radius: 8px; border: none; font-family: inherit; font-size: 13px; font-weight: 500; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: all 0.2s; }
.btn-primary { background: var(--accent); color: var(--bg); } .btn-primary:hover { background: #d4b46c; }
.btn-secondary { background: rgba(255,255,255,0.05); color: white; border: 1px solid var(--border); } .btn-secondary:hover { background: rgba(255,255,255,0.1); }
.btn-danger { background: rgba(255,82,82,0.1); color: var(--danger); border: 1px solid rgba(255,82,82,0.3); } .btn-danger:hover { background: var(--danger); color: white; }
.btn-draft { background: rgba(243, 156, 18, 0.1); color: var(--draft); border: 1px solid rgba(243, 156, 18, 0.3); } .btn-draft:hover { background: var(--draft); color: white; }
.btn-translate { background: rgba(52,152,219,0.1); color: var(--info); border: 1px solid rgba(52,152,219,0.3); padding: 6px 12px; font-size: 11px; border-radius: 6px; cursor: pointer; font-family: inherit; }
.btn-translate:hover { background: var(--info); color: white; }
.btn-translate-all { background: linear-gradient(135deg, #3498db, #2ecc71); color: white; border: none; padding: 10px 20px; font-size: 13px; font-weight: 600; border-radius: 8px; cursor: pointer; font-family: inherit; margin-bottom: 15px; }
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; }
.card { background: var(--bg2); border: 1px solid var(--border); border-radius: 12px; overflow: hidden; transition: all 0.3s; }
.card:hover { border-color: var(--accent); transform: translateY(-3px); }
.card-img { height: 180px; background-size: cover; background-position: center; background-color: #222; }
.card-body { padding: 18px; } .card-title { font-size: 17px; margin-bottom: 5px; } .card-meta { color: var(--muted); font-size: 12px; }
.card-actions { display: flex; gap: 8px; padding: 0 18px 18px; } .card-actions .btn { flex: 1; padding: 8px; font-size: 12px; }
.page { display: none; } .page.active { display: block; }
.modal-bg { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); backdrop-filter: blur(8px); z-index: 1000; overflow-y: auto; padding: 30px 15px; }
.modal-bg.show { display: block; }
.modal { background: var(--bg2); border: 1px solid var(--border); border-radius: 16px; width: 100%; max-width: 900px; margin: 0 auto; padding: 35px; position: relative; }
.modal h2 { font-size: 22px; margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border); }
.modal-close { position: absolute; top: 20px; left: 20px; width: 36px; height: 36px; border-radius: 50%; background: none; border: 1px solid var(--border); color: white; cursor: pointer; font-size: 16px; }
.form-group { margin-bottom: 15px; position: relative; }
.form-group label { display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: var(--muted); letter-spacing: 2px; margin-bottom: 6px; text-transform: uppercase; }
.form-group input, .form-group textarea, .form-group select { width: 100%; background: rgba(255,255,255,0.03); border: 1px solid var(--border); color: white; padding: 11px 15px; border-radius: 8px; font-family: inherit; font-size: 14px; }
.form-group input:focus, .form-group textarea:focus { outline: none; border-color: var(--accent); background: rgba(255,255,255,0.05); }
.form-group textarea { resize: vertical; min-height: 80px; }
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
.form-row-3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }
.lang-tabs { display: flex; gap: 6px; margin-bottom: 15px; border-bottom: 1px solid var(--border); padding-bottom: 10px; }
.lang-tab { padding: 7px 15px; border-radius: 6px; background: rgba(255,255,255,0.03); border: 1px solid var(--border); color: var(--muted); cursor: pointer; font-size: 12px; font-family: inherit; }
.lang-tab.active { background: var(--accent); color: var(--bg); border-color: var(--accent); }
.lang-content { display: none; } .lang-content.active { display: block; }
.section-block { background: var(--bg3); border: 1px solid var(--border); border-radius: 10px; margin-bottom: 15px; }
.section-head { padding: 15px 20px; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-size: 14px; font-weight: 500; }
.section-body { padding: 20px; border-top: 1px solid var(--border); display: none; }
.section-block.open .section-body { display: block; } .section-block.open .arrow { transform: rotate(180deg); }
.image-upload-item { background: var(--bg3); border: 1px solid var(--border); border-radius: 10px; padding: 15px; margin-bottom: 12px; display: grid; grid-template-columns: 100px 1fr auto; gap: 15px; align-items: center; }
.img-thumb { width: 100px; height: 75px; border-radius: 6px; background-size: cover; background-position: center; background-color: #222; }
.custom-field-block { background: var(--bg3); border: 1px solid var(--border); border-radius: 10px; padding: 15px; margin-bottom: 10px; }
.toast { position: fixed; bottom: 30px; left: 30px; padding: 14px 24px; border-radius: 10px; color: white; font-size: 14px; z-index: 9999; transform: translateY(100px); opacity: 0; transition: all 0.4s; max-width: 350px; }
.toast.show { transform: translateY(0); opacity: 1; }
.toast.success { background: var(--success); } .toast.error { background: var(--danger); } .toast.info { background: var(--info); }
.empty { text-align: center; padding: 80px 20px; color: var(--muted); } .empty .ico { font-size: 60px; opacity: 0.4; margin-bottom: 15px; }
.menu-item-editor { background: var(--bg3); border: 1px solid var(--border); border-radius: 8px; padding: 12px; margin-bottom: 8px; display: grid; grid-template-columns: auto 1fr 1fr 1fr auto auto; gap: 10px; align-items: center; }
.draft-badge { display:inline-block; background:rgba(243,156,18,0.2); color:#f39c12; padding:3px 8px; border-radius:4px; font-size:10px; margin-right:5px; }
.translate-info { background: linear-gradient(135deg, rgba(52,152,219,0.1), rgba(46,204,113,0.1)); border: 1px solid rgba(52,152,219,0.3); padding: 12px 18px; border-radius: 10px; margin-bottom: 15px; font-size: 13px; color: #a0d5ff; display: flex; align-items: center; gap: 10px; }
@media (max-width: 900px) { .sidebar { transform: translateX(100%); transition: transform 0.3s; } .sidebar.open { transform: translateX(0); } .main { margin-right: 0; padding: 15px; } .form-row, .form-row-3 { grid-template-columns: 1fr; } .mobile-btn { display: flex !important; } .modal { padding: 20px; } }
.mobile-btn { display: none; position: fixed; top: 15px; right: 15px; z-index: 100; width: 44px; height: 44px; border-radius: 10px; background: var(--accent); color: var(--bg); border: none; cursor: pointer; font-size: 20px; align-items: center; justify-content: center; }
</style>
</head>
<body>
<button class="mobile-btn" onclick="document.querySelector('.sidebar').classList.toggle('open')">☰</button>
<aside class="sidebar">
  <div class="sb-logo"><div class="mark">N</div><div><h2>NawAra Studio</h2><p>ADMIN PANEL</p></div></div>
  <div class="nav-item active" data-page="projects"><span class="icon">🏗️</span> پروژه‌ها</div>
  <div class="nav-item" data-page="news"><span class="icon">📰</span> اخبار</div>
  <div class="nav-item" data-page="about"><span class="icon">ℹ️</span> درباره ما</div>
  <div class="nav-item" data-page="contact"><span class="icon">📞</span> تماس</div>
  <div class="nav-item" data-page="header"><span class="icon">🎨</span> هدر سایت</div>
  <div class="nav-item" data-page="footer"><span class="icon">📋</span> فوتر سایت</div>
  <div class="nav-item" data-page="settings"><span class="icon">⚙️</span> تنظیمات</div>
  <a href="logout.php" class="logout">🚪 خروج از سیستم</a>
</aside>
<main class="main">

  <div class="page active" id="page-projects">
    <div class="page-header"><div><h1>مدیریت پروژه‌ها</h1><p class="sub">پروژه‌های ساختمانی و معماری</p></div><button class="btn btn-primary" onclick="openProjectModal()">+ پروژه جدید</button></div>
    <div class="grid" id="projectsList"></div>
  </div>

  <div class="page" id="page-news">
    <div class="page-header"><div><h1>مدیریت اخبار</h1></div><button class="btn btn-primary" onclick="openNewsModal()">+ خبر جدید</button></div>
    <div class="grid" id="newsList"></div>
  </div>

  <div class="page" id="page-about">
    <div class="page-header"><div><h1>درباره ما</h1></div><button class="btn btn-primary" onclick="saveAbout()">💾 ذخیره</button></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border);">
      <div class="translate-info"><span class="icon">🌐</span><span>در هر فیلد، متن را به یکی از زبان‌ها بنویسید و روی 🌐 کلیک کنید تا خودکار ترجمه شود.</span></div>
      <div class="lang-tabs"><button class="lang-tab active" onclick="switchLang(event,'about','fa')">فارسی</button><button class="lang-tab" onclick="switchLang(event,'about','ps')">پښتو</button><button class="lang-tab" onclick="switchLang(event,'about','en')">English</button></div>
      <?php foreach (['fa','ps','en'] as $l): ?>
        <div class="lang-content <?= $l==='fa'?'active':'' ?>" data-scope="about" data-lang="<?= $l ?>">
          <div class="form-group"><label>عنوان (<?= $l ?>) <button class="btn-translate" onclick="translateField('about-title','<?= $l ?>')">🌐 ترجمه</button></label><input type="text" id="about-title-<?= $l ?>" value="<?= htmlspecialchars($data['about']['title'][$l] ?? '') ?>"></div>
          <div class="form-group"><label>متن کامل (<?= $l ?>) <button class="btn-translate" onclick="translateField('about-content','<?= $l ?>')">🌐 ترجمه</button></label><textarea id="about-content-<?= $l ?>" rows="8"><?= htmlspecialchars($data['about']['content'][$l] ?? '') ?></textarea></div>
          <div class="form-group"><label>ماموریت و اهداف (<?= $l ?>) <button class="btn-translate" onclick="translateField('about-mission','<?= $l ?>')">🌐 ترجمه</button></label><textarea id="about-mission-<?= $l ?>" rows="4"><?= htmlspecialchars($data['about']['mission'][$l] ?? '') ?></textarea></div>
          <div class="form-group"><label>چشم انداز (<?= $l ?>) <button class="btn-translate" onclick="translateField('about-vision','<?= $l ?>')">🌐 ترجمه</button></label><textarea id="about-vision-<?= $l ?>" rows="4"><?= htmlspecialchars($data['about']['vision'][$l] ?? '') ?></textarea></div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="page" id="page-contact">
    <div class="page-header"><div><h1>اطلاعات تماس</h1></div><button class="btn btn-primary" onclick="saveContact()">💾 ذخیره</button></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border);">
      <div class="form-row"><div class="form-group"><label>تلفن اصلی</label><input type="text" id="contact-phone" value="<?= htmlspecialchars($data['contact']['phone'] ?? '') ?>"></div><div class="form-group"><label>تلفن دوم</label><input type="text" id="contact-phone2" value="<?= htmlspecialchars($data['contact']['phone2'] ?? '') ?>"></div></div>
      <div class="form-row"><div class="form-group"><label>ایمیل</label><input type="email" id="contact-email" value="<?= htmlspecialchars($data['contact']['email'] ?? '') ?>"></div><div class="form-group"><label>واتساپ (با کد کشور مثلاً 93700000000)</label><input type="text" id="contact-whatsapp" value="<?= htmlspecialchars($data['contact']['whatsapp'] ?? '') ?>"></div></div>
      <?php foreach (['fa','ps','en'] as $l): ?><div class="form-group"><label>آدرس (<?= $l ?>) <button class="btn-translate" onclick="translateField('contact-address','<?= $l ?>')">🌐 ترجمه</button></label><input type="text" id="contact-address-<?= $l ?>" value="<?= htmlspecialchars($data['contact']['address'][$l] ?? '') ?>"></div><?php endforeach; ?>
      <div class="form-row"><div class="form-group"><label>Instagram</label><input type="text" id="contact-instagram" value="<?= htmlspecialchars($data['contact']['instagram'] ?? '') ?>"></div><div class="form-group"><label>Facebook</label><input type="text" id="contact-facebook" value="<?= htmlspecialchars($data['contact']['facebook'] ?? '') ?>"></div></div>
      <div class="form-row"><div class="form-group"><label>LinkedIn</label><input type="text" id="contact-linkedin" value="<?= htmlspecialchars($data['contact']['linkedin'] ?? '') ?>"></div><div class="form-group"><label>Twitter/X</label><input type="text" id="contact-twitter" value="<?= htmlspecialchars($data['contact']['twitter'] ?? '') ?>"></div></div>
    </div>
  </div>

  <div class="page" id="page-header">
    <div class="page-header"><div><h1>سفارشی‌سازی هدر</h1></div><button class="btn btn-primary" onclick="saveSettings()">💾 ذخیره</button></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border);"><div class="form-row-3"><div class="form-group"><label>متن لوگو (فارسی)</label><input type="text" id="hdr-logo-fa" value="<?= htmlspecialchars($settings['header']['logo_text']['fa'] ?? 'نو آرا') ?>"></div><div class="form-group"><label>متن لوگو (پښتو)</label><input type="text" id="hdr-logo-ps" value="<?= htmlspecialchars($settings['header']['logo_text']['ps'] ?? 'نوآرا') ?>"></div><div class="form-group"><label>Logo Text (EN)</label><input type="text" id="hdr-logo-en" value="<?= htmlspecialchars($settings['header']['logo_text']['en'] ?? 'NawAra') ?>"></div></div><div id="menuItemsList"></div><button class="btn btn-secondary" onclick="addMenuItem()">+ افزودن گزینه</button></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border); margin-top:18px;">
      <h3 style="font-size:14px; color:var(--accent); margin-bottom:8px;">🎬 تصویر یا ویدیوی هوم پیج</h3>
      <p style="font-size:12px;color:var(--muted);line-height:1.8;margin-bottom:15px;">برای هوم پیج می‌توانید یک تصویر یا ویدیوی کوتاه MP4 / WebM / MOV آپلود کنید. اگر ویدیو انتخاب شود، در پس‌زمینه به صورت خودکار و بدون صدا پخش می‌شود.</p>
      <div class="form-group"><label>فایل جدید (حداکثر 25MB)</label><input type="file" id="hero-media" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm,video/quicktime"></div>
      <div style="margin-top:20px;border-top:1px solid var(--border);padding-top:18px;"><h4 style="font-size:13px;margin-bottom:12px;color:var(--accent);">✍️ متن‌های هوم پیج</h4><p style="font-size:11px;color:var(--muted);margin-bottom:14px;">متن هر زبان را جداگانه تغییر بدهید. اگر خالی باشد متن پیش‌فرض سایت استفاده می‌شود.</p><div class="lang-tabs"><button type="button" class="lang-tab active" onclick="switchLang(event,'hero','fa')">فارسی</button><button type="button" class="lang-tab" onclick="switchLang(event,'hero','ps')">پښتو</button><button type="button" class="lang-tab" onclick="switchLang(event,'hero','en')">English</button></div>
      <?php foreach(['fa','ps','en'] as $l): ?><div class="lang-content <?= $l==='fa'?'active':'' ?>" data-scope="hero" data-lang="<?= $l ?>"><div class="form-group"><label>عنوان اصلی</label><textarea id="hero-title-<?= $l ?>" rows="2"><?= htmlspecialchars($settings['hero']['title'][$l] ?? '') ?></textarea></div><div class="form-group"><label>متن کوچک بالای عنوان</label><input type="text" id="hero-eyebrow-<?= $l ?>" value="<?= htmlspecialchars($settings['hero']['eyebrow'][$l] ?? '') ?>"></div><div class="form-group"><label>توضیحات</label><textarea id="hero-description-<?= $l ?>" rows="3"><?= htmlspecialchars($settings['hero']['description'][$l] ?? '') ?></textarea></div><div class="form-group"><label>متن دکمه</label><input type="text" id="hero-cta-<?= $l ?>" value="<?= htmlspecialchars($settings['hero']['cta'][$l] ?? '') ?>"></div></div><?php endforeach; ?></div>
      <?php if (!empty($settings['hero']['media'])): ?><div style="margin:12px 0;font-size:11px;color:var(--muted);">فایل فعلی: <?= htmlspecialchars($settings['hero']['media']) ?></div><?php endif; ?>
      <button class="btn btn-secondary" onclick="saveHeroMedia()">💾 ذخیره رسانه هوم پیج</button>
    </div>
  </div>

  <div class="page" id="page-footer">
    <div class="page-header"><div><h1>سفارشی‌سازی فوتر</h1></div><button class="btn btn-primary" onclick="saveSettings()">💾 ذخیره</button></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border);"><div class="form-row-3"><div class="form-group"><label>Copyright (FA)</label><input type="text" id="ftr-copy-fa" value="<?= htmlspecialchars($settings['footer']['copyright']['fa'] ?? '') ?>"></div><div class="form-group"><label>Copyright (PS)</label><input type="text" id="ftr-copy-ps" value="<?= htmlspecialchars($settings['footer']['copyright']['ps'] ?? '') ?>"></div><div class="form-group"><label>Copyright (EN)</label><input type="text" id="ftr-copy-en" value="<?= htmlspecialchars($settings['footer']['copyright']['en'] ?? '') ?>"></div></div><div id="footerColumnsList"></div><button class="btn btn-secondary" onclick="addFooterColumn()">+ افزودن ستون</button></div>
  </div>

  <div class="page" id="page-settings">
    <div class="page-header"><div><h1>تنظیمات حساب و ظاهر</h1></div></div>
    <div style="background:var(--bg2); padding:25px; border-radius:12px; border:1px solid var(--border); max-width:500px;">
      <div class="form-group"><label>نام کاربری جدید (اختیاری)</label><input type="text" id="new-username" placeholder="<?= htmlspecialchars($adminInfo['username'] ?? '') ?>"></div>
      <div class="form-group"><label>رمز عبور فعلی</label><input type="password" id="current-password"></div>
      <div class="form-group"><label>رمز جدید (حداقل ۸ کاراکتر)</label><input type="password" id="new-password"></div>
      <div class="form-group"><label>تکرار رمز جدید</label><input type="password" id="confirm-password"></div>
      <button class="btn btn-primary" onclick="changePassword()" style="width:100%;">🔒 تغییر رمز عبور</button>

      <hr style="border-color:var(--border); margin:25px 0;">
      <h3 style="font-size:14px; color:var(--accent); margin-bottom:15px;">🎨 تنظیمات گرافیک عکس‌ها</h3>
      <div class="form-group">
        <label>میزان گردی حاشیه عکس‌های سایت (Border Radius)</label>
        <select id="setting-radius">
          <option value="0px" <?= ($settings['card_radius']??'')==='0px'?'selected':'' ?>>تیز و مربعی (0px)</option>
          <option value="12px" <?= ($settings['card_radius']??'')==='12px'?'selected':'' ?>>کمی گرد - استاندارد (12px)</option>
          <option value="24px" <?= ($settings['card_radius']??'')==='24px'?'selected':'' ?>>کاملاً گرد - مدرن (24px)</option>
        </select>
      </div>
      <button class="btn btn-secondary" onclick="saveGraphicSettings()" style="width:100%;">💾 ذخیره تنظیمات حاشیه عکس‌ها</button>
    </div>
  </div>

</main>

<div class="modal-bg" id="projectModal">
  <div class="modal">
    <button class="modal-close" onclick="closeProjectModal()">✕</button>
    <h2 id="projectModalTitle">پروژه جدید</h2>
    <div class="translate-info"><span class="icon">🌐</span><div><strong>ترجمه هوشمند:</strong> در هر فیلد، متن را به یکی از زبان‌ها بنویسید و روی دکمه 🌐 کلیک کنید تا خودکار ترجمه شود.<br><button class="btn-translate-all" onclick="translateAllProjectFields()" style="margin-top:10px;">🌐 ترجمه همه فیلدهای فارسی به پشتو و انگلیسی</button></div></div>
    
    <div class="section-block open">
      <div class="section-head" onclick="this.parentElement.classList.toggle('open')"><span>📌 اطلاعات اصلی</span><span class="arrow">▼</span></div>
      <div class="section-body">
        <div class="lang-tabs"><button type="button" class="lang-tab active" onclick="switchLang(event,'basic','fa')">فارسی</button><button type="button" class="lang-tab" onclick="switchLang(event,'basic','ps')">پښتو</button><button type="button" class="lang-tab" onclick="switchLang(event,'basic','en')">English</button></div>
        <?php foreach(['fa','ps','en'] as $l): ?>
        <div class="lang-content <?= $l==='fa'?'active':'' ?>" data-scope="basic" data-lang="<?= $l ?>">
          <div class="form-row">
            <div class="form-group"><label>نام پروژه (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-name','<?= $l ?>')">🌐</button></label><input type="text" id="p-name-<?= $l ?>"></div>
            <div class="form-group"><label>موقعیت (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-location','<?= $l ?>')">🌐</button></label><input type="text" id="p-location-<?= $l ?>"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>نوع پروژه (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-type','<?= $l ?>')">🌐</button></label><input type="text" id="p-type-<?= $l ?>"></div>
            <div class="form-group"><label>وضعیت (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-status','<?= $l ?>')">🌐</button></label><input type="text" id="p-status-<?= $l ?>"></div>
          </div>
          <div class="form-group"><label>کارفرما (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-client','<?= $l ?>')">🌐</button></label><input type="text" id="p-client-<?= $l ?>"></div>
          <div class="form-group"><label>توضیحات کامل (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-desc','<?= $l ?>')">🌐</button></label><textarea id="p-desc-<?= $l ?>" rows="5"></textarea></div>
        </div>
        <?php endforeach; ?>
        <hr style="border:none;border-top:1px solid var(--border);margin:15px 0;">
        <div class="form-row-3"><div class="form-group"><label>سال</label><input type="text" id="p-year" placeholder="2024"></div><div class="form-group"><label>مساحت زمین</label><input type="text" id="p-size" placeholder="45,000 m²"></div><div class="form-group"><label>تعداد طبقات</label><input type="text" id="p-floors" placeholder="25"></div></div>
        
        <!-- NEW GOOGLE MAP FIELD -->
        <div class="form-group" style="margin-top:15px;">
          <label>لینک نقشه گوگل (فقط محتوای src داخل تگ iframe را کپی کنید) اختیاری</label>
          <input type="text" id="p-map" placeholder="https://www.google.com/maps/embed?pb=!1m18...">
        </div>
      </div>
    </div>

    <div class="section-block">
      <div class="section-head" onclick="this.parentElement.classList.toggle('open')"><span>👥 تیم پروژه</span><span class="arrow">▼</span></div>
      <div class="section-body">
        <div class="lang-tabs"><button type="button" class="lang-tab active" onclick="switchLang(event,'team','fa')">فارسی</button><button type="button" class="lang-tab" onclick="switchLang(event,'team','ps')">پښتو</button><button type="button" class="lang-tab" onclick="switchLang(event,'team','en')">English</button></div>
        <?php 
        $teamFields = ['project_leader'=>'رهبر پروژه','project_architect'=>'مهندس پروژه','structural_engineer'=>'مهندس ساختمان','electrical_engineer'=>'مهندس برق','mechanical_engineer'=>'مهندس مکانیک','interior_designer'=>'طراح داخلی','landscape_designer'=>'طراح محوطه','contractor'=>'پیمانکار'];
        foreach(['fa','ps','en'] as $l): ?>
        <div class="lang-content <?= $l==='fa'?'active':'' ?>" data-scope="team" data-lang="<?= $l ?>">
          <?php foreach($teamFields as $f => $label): ?>
            <div class="form-group"><label><?= $label ?> (<?= $l ?>) <button class="btn-translate" onclick="translateField('p-<?= $f ?>','<?= $l ?>')">🌐</button></label><input type="text" id="p-<?= $f ?>-<?= $l ?>"></div>
          <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="section-block">
      <div class="section-head" onclick="this.parentElement.classList.toggle('open')"><span>➕ فیلدهای سفارشی (اختیاری)</span><span class="arrow">▼</span></div>
      <div class="section-body"><div id="customFieldsList"></div><button type="button" class="btn btn-secondary" onclick="addCustomField()">+ افزودن فیلد جدید</button></div>
    </div>

    <div class="section-block open">
      <div class="section-head" onclick="this.parentElement.classList.toggle('open')"><span>🖼️🎥 تصاویر و ویدیوهای پروژه</span><span class="arrow">▼</span></div>
      <div class="section-body"><button type="button" class="btn btn-secondary" onclick="document.getElementById('imgUploader').click()">+ آپلود عکس یا ویدیو جدید</button><input type="file" id="imgUploader" accept="image/*, video/*" style="display:none;" onchange="addImage(event)"><div id="imagesList" style="margin-top:15px;"></div></div>
    </div>

    <div style="display:flex; gap:10px; margin-top:25px; flex-wrap:wrap;">
      <button type="button" class="btn btn-primary" onclick="saveProject(false)">🌍 انتشار پروژه</button>
      <button type="button" class="btn btn-draft" onclick="saveProject(true)">💾 ذخیره پیش‌نویس</button>
      <button type="button" class="btn btn-secondary" onclick="closeProjectModal()">بستن</button>
    </div>
  </div>
</div>

<div class="modal-bg" id="newsModal">
  <div class="modal"><button class="modal-close" onclick="closeNewsModal()">✕</button><h2>خبر جدید</h2>
  <div class="translate-info"><span class="icon">🌐</span><span>در یک زبان بنویسید و روی 🌐 کلیک کنید تا ترجمه شود.</span></div>
  <div class="lang-tabs"><button type="button" class="lang-tab active" onclick="switchLang(event,'news','fa')">فارسی</button><button type="button" class="lang-tab" onclick="switchLang(event,'news','ps')">پښتو</button><button type="button" class="lang-tab" onclick="switchLang(event,'news','en')">English</button></div>
  <?php foreach(['fa','ps','en'] as $l): ?><div class="lang-content <?= $l==='fa'?'active':'' ?>" data-scope="news" data-lang="<?= $l ?>"><div class="form-group"><label>عنوان خبر (<?= $l ?>) <button class="btn-translate" onclick="translateField('n-title','<?= $l ?>')">🌐</button></label><input type="text" id="n-title-<?= $l ?>"></div><div class="form-group"><label>متن خبر (<?= $l ?>) <button class="btn-translate" onclick="translateField('n-content','<?= $l ?>')">🌐</button></label><textarea id="n-content-<?= $l ?>" rows="8"></textarea></div></div><?php endforeach; ?>
  <div class="form-group"><label>تاریخ</label><input type="date" id="n-date"></div><div class="form-group"><label>تصویر یا ویدیوی خبر</label><input type="file" id="n-image" accept="image/*, video/*"><div id="n-image-preview" style="margin-top:10px;"></div></div><div style="display:flex; gap:10px; margin-top:20px;"><button type="button" class="btn btn-primary" onclick="saveNews()">💾 ذخیره</button><button type="button" class="btn btn-secondary" onclick="closeNewsModal()">انصراف</button></div></div>
</div>

<div class="toast" id="toast"></div>

<script>
let CSRF = '<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>';
let allProjects = <?= json_encode($data['projects'] ?? [], JSON_UNESCAPED_UNICODE) ?>;
let allNews = <?= json_encode($data['news'] ?? [], JSON_UNESCAPED_UNICODE) ?>;
let settings = <?= json_encode($settings, JSON_UNESCAPED_UNICODE) ?>;
let editingProject = null; let editingNews = null; let currentGallery = []; let customFields = [];
let menuItems = settings.header?.menu_items || [{key:'projects',label:{fa:'پروژه‌ها',ps:'پروژې',en:'Projects'},visible:true},{key:'news',label:{fa:'اخبار',ps:'خبرونه',en:'News'},visible:true},{key:'about',label:{fa:'درباره ما',ps:'زموږ په اړه',en:'About'},visible:true},{key:'contact',label:{fa:'تماس',ps:'اړیکه',en:'Contact'},visible:true}];
let footerColumns = settings.footer?.columns || [];

async function translateText(text, from, to) {
  if (!text || !text.trim()) return '';
  if (from === to) return text;
  try {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${from}&tl=${to}&dt=t&q=${encodeURIComponent(text)}`;
    const res = await fetch(url); const data = await res.json();
    if (data && data[0]) { let translated = ''; data[0].forEach(s => { if (s[0]) translated += s[0]; }); return translated; }
    return text;
  } catch (err) { return text; }
}

async function translateField(fieldPrefix, sourceLang) {
  const sourceEl = document.getElementById(`${fieldPrefix}-${sourceLang}`);
  if (!sourceEl || !sourceEl.value.trim()) return toast('فیلد خالی است', 'error');
  toast('🌐 در حال ترجمه...', 'info');
  const targetLangs = ['fa','ps','en'].filter(l => l !== sourceLang);
  for (const targetLang of targetLangs) {
    const targetEl = document.getElementById(`${fieldPrefix}-${targetLang}`);
    if (targetEl) targetEl.value = await translateText(sourceEl.value.trim(), sourceLang, targetLang);
  }
  toast('✅ ترجمه شد', 'success');
}

async function translateAllProjectFields() {
  const fields = ['p-name','p-location','p-type','p-status','p-client','p-desc','p-project_leader','p-project_architect','p-structural_engineer','p-electrical_engineer','p-mechanical_engineer','p-interior_designer','p-landscape_designer','p-contractor'];
  toast('🌐 در حال ترجمه همه فیلدها...', 'info');
  for (const field of fields) {
    const faEl = document.getElementById(`${field}-fa`);
    if (faEl && faEl.value.trim()) {
      await translateField(field, 'fa');
      await new Promise(r => setTimeout(r, 200));
    }
  }
  toast('✅ همه فیلدها ترجمه شدند', 'success');
}

async function apiPost(fd) {
  fd.set('csrf_token', CSRF);
  let res = await fetch('ajax.php', { method: 'POST', body: fd });
  let data = await res.json();
  if (data.code === 'csrf' && data.new_token) {
    CSRF = data.new_token; fd.set('csrf_token', CSRF);
    res = await fetch('ajax.php', { method: 'POST', body: fd });
    data = await res.json();
  }
  if (data.code === 'auth') { toast('دوباره وارد شوید', 'error'); setTimeout(()=>location.href='index.php',1500); }
  return data;
}

document.querySelectorAll('.nav-item').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('.nav-item, .page').forEach(n => n.classList.remove('active'));
    el.classList.add('active'); document.getElementById('page-' + el.dataset.page).classList.add('active');
  });
});

function switchLang(e, scope, lang) {
  const container = e.target.closest('.modal') || e.target.closest('div[style*="background"]');
  const tabsBar = e.target.closest('.lang-tabs');
  tabsBar.querySelectorAll('.lang-tab').forEach(t => t.classList.remove('active'));
  e.target.classList.add('active');
  container.querySelectorAll(`.lang-content[data-scope="${scope}"]`).forEach(c => c.classList.remove('active'));
  container.querySelector(`.lang-content[data-scope="${scope}"][data-lang="${lang}"]`).classList.add('active');
}

function toast(msg, type='success') {
  const t = document.getElementById('toast'); t.textContent = msg; t.className = 'toast show ' + type;
  setTimeout(() => t.classList.remove('show'), 3500);
}

function escapeHtml(s) { const d = document.createElement('div'); d.textContent = s||''; return d.innerHTML; }
function escapeAttr(s) { return (s||'').replace(/"/g, '&quot;'); }
function getLangValues(prefix) { return { fa: document.getElementById(prefix+'-fa')?.value||'', ps: document.getElementById(prefix+'-ps')?.value||'', en: document.getElementById(prefix+'-en')?.value||'' }; }

function renderProjects() {
  const list = document.getElementById('projectsList');
  if (!allProjects.length) { list.innerHTML = '<div class="empty" style="grid-column:1/-1;"><h3>هنوز پروژه‌ای نیست</h3></div>'; return; }
  list.innerHTML = allProjects.map(p => `
    <div class="card">
      <div class="card-img" style="background-image:url('../${p.image||''}')"></div>
      <div class="card-body">
        <div class="card-title">${escapeHtml(p.name?.fa || p.name?.en || 'بدون نام')} ${p.is_draft ? '<span class="draft-badge">پیش‌نویس</span>' : ''}</div>
        <div class="card-meta">${escapeHtml(p.location?.fa||'')} • ${escapeHtml(p.year||'')}</div>
      </div>
      <div class="card-actions">
        <button class="btn btn-secondary" onclick="editProject(${p.id})">✏️ ویرایش</button>
        <button class="btn btn-danger" onclick="deleteProject(${p.id})">🗑️ حذف</button>
      </div>
    </div>`).join('');
}

function openProjectModal() {
  editingProject = null; currentGallery = []; customFields = [];
  document.getElementById('projectModalTitle').textContent = 'پروژه جدید';
  document.querySelectorAll('#projectModal input, #projectModal textarea').forEach(i => { if(i.type!=='file') i.value = ''; });
  renderImagesList(); renderCustomFields(); document.getElementById('projectModal').classList.add('show');
}
function closeProjectModal() { document.getElementById('projectModal').classList.remove('show'); }

function editProject(id) {
  const p = allProjects.find(x => x.id === id); if (!p) return;
  editingProject = id; document.getElementById('projectModalTitle').textContent = 'ویرایش پروژه';
  ['fa','ps','en'].forEach(l => {
    ['name','location','type','status','client'].forEach(f => { const el = document.getElementById(`p-${f}-${l}`); if(el) el.value = p[f]?.[l] || ''; });
    const descEl = document.getElementById(`p-desc-${l}`); if(descEl) descEl.value = p.description?.[l] || '';
  });
  ['project_leader','project_architect','structural_engineer','electrical_engineer','mechanical_engineer','interior_designer','landscape_designer','contractor'].forEach(f => {
    ['fa','ps','en'].forEach(l => { const el = document.getElementById(`p-${f}-${l}`); if(el) el.value = p[f]?.[l] || ''; });
  });
  ['year','size','floors','map'].forEach(f => { const el = document.getElementById('p-'+f); if(el) el.value = p[f] || ''; });
  currentGallery = (p.gallery||[]).map(g => ({...g, isNew: false})); customFields = p.custom_fields||[];
  renderImagesList(); renderCustomFields(); document.getElementById('projectModal').classList.add('show');
}

async function deleteProject(id) {
  if (!confirm('حذف پروژه؟')) return;
  const fd = new FormData(); fd.append('action', 'delete_project'); fd.append('id', id);
  const data = await apiPost(fd);
  if (data.success) { allProjects = allProjects.filter(p=>p.id!==id); renderProjects(); toast('حذف شد'); }
}

async function saveProject(isDraft = false) {
  const pData = {
    id: editingProject, is_draft: isDraft,
    name: getLangValues('p-name'), location: getLangValues('p-location'), type: getLangValues('p-type'), status: getLangValues('p-status'), client: getLangValues('p-client'), description: getLangValues('p-desc'),
    year: document.getElementById('p-year').value, size: document.getElementById('p-size').value, floors: document.getElementById('p-floors').value, map: document.getElementById('p-map').value,
    project_leader: getLangValues('p-project_leader'), project_architect: getLangValues('p-project_architect'), structural_engineer: getLangValues('p-structural_engineer'), electrical_engineer: getLangValues('p-electrical_engineer'), mechanical_engineer: getLangValues('p-mechanical_engineer'), interior_designer: getLangValues('p-interior_designer'), landscape_designer: getLangValues('p-landscape_designer'), contractor: getLangValues('p-contractor'),
    custom_fields: customFields, gallery: currentGallery.filter(g => !g.isNew)
  };
  const fd = new FormData(); fd.append('action', 'save_project'); fd.append('project_data', JSON.stringify(pData));
  currentGallery.filter(g => g.isNew).forEach(img => { fd.append('new_images[]', img.file); fd.append('image_names[]', img.name?.fa||''); fd.append('image_names_en[]', img.name?.en||''); });
  toast('در حال ذخیره...', 'info');
  const data = await apiPost(fd);
  if (data.success) { toast(isDraft ? 'پیش‌نویس ذخیره شد' : 'پروژه منتشر شد ✅'); setTimeout(()=>location.reload(),1000); } else toast(data.error||'خطا','error');
}

function addImage(e) {
  const file = e.target.files[0]; if(!file) return;
  const name = prompt('نام تصویر/ویدیو (فارسی):', ''); const nameEn = prompt('Media name (EN):', '');
  const reader = new FileReader(); reader.onload = ev => { currentGallery.push({url:ev.target.result, name:{fa:name||'',ps:name||'',en:nameEn||name||''}, isNew:true, file:file}); renderImagesList(); };
  reader.readAsDataURL(file); e.target.value = '';
}
function renderImagesList() {
  const list = document.getElementById('imagesList');
  if(!currentGallery.length) { list.innerHTML = '<p style="color:var(--muted);text-align:center;">فایلی نیست</p>'; return; }
  list.innerHTML = currentGallery.map((img,i) => `<div class="image-upload-item"><div class="img-thumb" style="background-image:url('${img.isNew?img.url:'../'+img.url}')"></div><div><div class="form-group"><label>نام (FA/PS)</label><input type="text" value="${escapeAttr(img.name?.fa||'')}" onchange="currentGallery[${i}].name.fa=this.value;currentGallery[${i}].name.ps=this.value"></div><div class="form-group" style="margin:0;"><label>Name (EN)</label><input type="text" value="${escapeAttr(img.name?.en||'')}" onchange="currentGallery[${i}].name.en=this.value"></div></div><div style="display:flex;flex-direction:column;gap:5px;">${i>0?`<button class="btn btn-secondary" onclick="moveImg(${i},-1)">↑</button>`:''}${i<currentGallery.length-1?`<button class="btn btn-secondary" onclick="moveImg(${i},1)">↓</button>`:''}<button class="btn btn-danger" onclick="if(confirm('حذف؟')){currentGallery.splice(${i},1);renderImagesList();}">🗑️</button></div></div>`).join('');
}
function moveImg(i,dir) { const t=currentGallery[i]; currentGallery[i]=currentGallery[i+dir]; currentGallery[i+dir]=t; renderImagesList(); }

function addCustomField() { const l=prompt('نام فیلد (FA):',''); if(!l)return; const lEn=prompt('Field name (EN):',l); customFields.push({label:{fa:l,ps:l,en:lEn||l},value:{fa:'',ps:'',en:''}}); renderCustomFields(); }
function renderCustomFields() {
  const list = document.getElementById('customFieldsList');
  if(!customFields.length){list.innerHTML='<p style="color:var(--muted);text-align:center;">فیلدی نیست</p>';return;}
  list.innerHTML=customFields.map((f,i)=>`<div class="custom-field-block"><div style="display:flex;justify-content:space-between;margin-bottom:10px;"><strong>${escapeHtml(f.label.fa)} / ${escapeHtml(f.label.en)}</strong><button class="btn btn-danger" onclick="customFields.splice(${i},1);renderCustomFields()">حذف</button></div><div class="form-row-3"><div class="form-group"><label>FA <button class="btn-translate" onclick="translateCustomField(${i},'fa')">🌐</button></label><input type="text" id="cf-${i}-fa" value="${escapeAttr(f.value.fa)}" oninput="customFields[${i}].value.fa=this.value"></div><div class="form-group"><label>PS <button class="btn-translate" onclick="translateCustomField(${i},'ps')">🌐</button></label><input type="text" id="cf-${i}-ps" value="${escapeAttr(f.value.ps)}" oninput="customFields[${i}].value.ps=this.value"></div><div class="form-group"><label>EN <button class="btn-translate" onclick="translateCustomField(${i},'en')">🌐</button></label><input type="text" id="cf-${i}-en" value="${escapeAttr(f.value.en)}" oninput="customFields[${i}].value.en=this.value"></div></div></div>`).join('');
}
async function translateCustomField(index, sourceLang) {
  const src = document.getElementById(`cf-${index}-${sourceLang}`).value;
  if (!src) return toast('فیلد خالی است', 'error');
  toast('🌐 در حال ترجمه...', 'info');
  const targets = ['fa','ps','en'].filter(l => l !== sourceLang);
  for (const t of targets) {
    const translated = await translateText(src, sourceLang, t);
    document.getElementById(`cf-${index}-${t}`).value = translated;
    customFields[index].value[t] = translated;
  }
  toast('✅ ترجمه شد');
}

// NEWS
function renderNews() { document.getElementById('newsList').innerHTML = allNews.length ? allNews.map(n=>`<div class="card"><div class="card-img" style="background-image:url('../${n.image||''}')"></div><div class="card-body"><div class="card-title">${escapeHtml(n.title?.fa||n.title?.en||'')}</div><div class="card-meta">${escapeHtml(n.date||'')}</div></div><div class="card-actions"><button class="btn btn-secondary" onclick="editNews(${n.id})">✏️</button><button class="btn btn-danger" onclick="deleteNews(${n.id})">🗑️</button></div></div>`).join('') : '<div class="empty"><h3>خبری نیست</h3></div>'; }
function openNewsModal() { editingNews=null; document.querySelectorAll('#newsModal input, #newsModal textarea').forEach(i=>{if(i.type!=='file')i.value='';}); document.getElementById('n-date').value=new Date().toISOString().split('T')[0]; document.getElementById('n-image-preview').innerHTML=''; document.getElementById('newsModal').classList.add('show'); }
function closeNewsModal() { document.getElementById('newsModal').classList.remove('show'); }
function editNews(id) { const n=allNews.find(x=>x.id===id); if(!n)return; editingNews=id; ['fa','ps','en'].forEach(l=>{document.getElementById('n-title-'+l).value=n.title?.[l]||''; document.getElementById('n-content-'+l).value=n.content?.[l]||'';}); document.getElementById('n-date').value=n.date||''; document.getElementById('n-image-preview').innerHTML=n.image?`<img src="../${n.image}" style="max-width:200px;">`:''; document.getElementById('newsModal').classList.add('show'); }
async function saveNews() { const fd=new FormData(); fd.append('action','save_news'); fd.append('news_data',JSON.stringify({id:editingNews, title:getLangValues('n-title'), content:getLangValues('n-content'), date:document.getElementById('n-date').value, image:editingNews?allNews.find(n=>n.id===editingNews)?.image:''})); const f=document.getElementById('n-image').files[0]; if(f)fd.append('image',f); const d=await apiPost(fd); if(d.success){toast('ذخیره شد');setTimeout(()=>location.reload(),800);} }
async function deleteNews(id) { if(!confirm('حذف؟'))return; const fd=new FormData(); fd.append('action','delete_news'); fd.append('id',id); await apiPost(fd); allNews=allNews.filter(n=>n.id!==id); renderNews(); toast('حذف شد'); }

// OTHERS
async function saveAbout() { const fd=new FormData(); fd.append('action','save_about'); fd.append('about_data',JSON.stringify({title:getLangValues('about-title'),content:getLangValues('about-content'),mission:getLangValues('about-mission'),vision:getLangValues('about-vision')})); await apiPost(fd); toast('ذخیره شد'); }
async function saveContact() { const fd=new FormData(); fd.append('action','save_contact'); fd.append('contact_data',JSON.stringify({phone:document.getElementById('contact-phone').value,phone2:document.getElementById('contact-phone2').value,email:document.getElementById('contact-email').value,whatsapp:document.getElementById('contact-whatsapp').value,address:getLangValues('contact-address'),instagram:document.getElementById('contact-instagram').value,facebook:document.getElementById('contact-facebook').value,linkedin:document.getElementById('contact-linkedin').value,twitter:document.getElementById('contact-twitter').value})); await apiPost(fd); toast('ذخیره شد'); }
function renderMenuItems() { document.getElementById('menuItemsList').innerHTML=menuItems.map((m,i)=>`<div class="menu-item-editor"><input type="checkbox" ${m.visible?'checked':''} onchange="menuItems[${i}].visible=this.checked"><input type="text" value="${escapeAttr(m.label.fa)}" oninput="menuItems[${i}].label.fa=this.value" placeholder="FA"><input type="text" value="${escapeAttr(m.label.ps)}" oninput="menuItems[${i}].label.ps=this.value" placeholder="PS"><input type="text" value="${escapeAttr(m.label.en)}" oninput="menuItems[${i}].label.en=this.value" placeholder="EN"><button class="btn btn-secondary" onclick="const t=menuItems[${i}];menuItems[${i}]=menuItems[${i-1}];menuItems[${i-1}]=t;renderMenuItems()" ${i===0?'disabled':''}>↑</button><button class="btn btn-danger" onclick="menuItems.splice(${i},1);renderMenuItems()">🗑️</button></div>`).join(''); }
function addMenuItem() { const k=prompt('Key (EN):','new'); if(k){menuItems.push({key:k,label:{fa:'جدید',ps:'نوی',en:'New'},visible:true}); renderMenuItems();} }
function renderFooterColumns() { document.getElementById('footerColumnsList').innerHTML=footerColumns.map((c,i)=>`<div class="section-block open"><div class="section-head">ستون ${i+1} <button class="btn btn-danger" onclick="footerColumns.splice(${i},1);renderFooterColumns()">حذف</button></div><div class="section-body"><div class="form-row-3"><div class="form-group"><label>FA</label><input value="${escapeAttr(c.title?.fa||'')}" oninput="footerColumns[${i}].title.fa=this.value"></div><div class="form-group"><label>PS</label><input value="${escapeAttr(c.title?.ps||'')}" oninput="footerColumns[${i}].title.ps=this.value"></div><div class="form-group"><label>EN</label><input value="${escapeAttr(c.title?.en||'')}" oninput="footerColumns[${i}].title.en=this.value"></div></div><div class="form-row-3"><div class="form-group"><label>FA</label><textarea rows="3" oninput="footerColumns[${i}].content.fa=this.value">${escapeHtml(c.content?.fa||'')}</textarea></div><div class="form-group"><label>PS</label><textarea rows="3" oninput="footerColumns[${i}].content.ps=this.value">${escapeHtml(c.content?.ps||'')}</textarea></div><div class="form-group"><label>EN</label><textarea rows="3" oninput="footerColumns[${i}].content.en=this.value">${escapeHtml(c.content?.en||'')}</textarea></div></div></div></div>`).join(''); }
function addFooterColumn() { footerColumns.push({title:{fa:'',ps:'',en:''},content:{fa:'',ps:'',en:''}}); renderFooterColumns(); }

async function saveHeroMedia() {
  const f=document.getElementById('hero-media')?.files?.[0];
  const fd=new FormData(); fd.append('action','save_hero_media');
  if(f) fd.append('hero_media',f);
  const h=settings.hero||{}; h.title=getLangValues('hero-title'); h.eyebrow=getLangValues('hero-eyebrow'); h.description=getLangValues('hero-description'); h.cta=getLangValues('hero-cta');
  fd.append('hero_data',JSON.stringify(h));
  if(!f && !h.title.fa && !h.title.ps && !h.title.en){ toast('حداقل یک متن یا رسانه وارد کنید','error'); return; }
  const d=await apiPost(fd); if(d.success){ toast('تنظیمات هوم پیج ذخیره شد ✅'); setTimeout(()=>location.reload(),700); } else toast(d.error||'خطا در ذخیره','error');
}

async function saveSettings() { 
  settings.header = { logo_text: { fa:document.getElementById('hdr-logo-fa').value, ps:document.getElementById('hdr-logo-ps').value, en:document.getElementById('hdr-logo-en').value }, menu_items:menuItems };
  settings.footer = { copyright: { fa:document.getElementById('ftr-copy-fa').value, ps:document.getElementById('ftr-copy-ps').value, en:document.getElementById('ftr-copy-en').value }, columns:footerColumns };
  const fd = new FormData(); fd.append('action','save_settings'); fd.append('settings_data',JSON.stringify(settings));
  await apiPost(fd); toast('تنظیمات ذخیره شد');
}

async function saveGraphicSettings() {
  settings.card_radius = document.getElementById('setting-radius').value;
  const fd = new FormData(); fd.append('action','save_settings'); fd.append('settings_data',JSON.stringify(settings));
  await apiPost(fd); toast('تنظیمات گرافیک عکس‌ها ذخیره شد ✅');
}

async function changePassword() { const fd=new FormData(); fd.append('action','change_password'); fd.append('current_password',document.getElementById('current-password').value); fd.append('new_password',document.getElementById('new-password').value); fd.append('confirm_password',document.getElementById('confirm-password').value); if(document.getElementById('new-username').value) fd.append('new_username',document.getElementById('new-username').value); const d=await apiPost(fd); if(d.success){toast(d.message);document.querySelectorAll('#page-settings input').forEach(i=>i.value='');}else toast(d.error,'error'); }

renderProjects(); renderNews(); renderMenuItems(); renderFooterColumns();
</script>
</body>
</html>