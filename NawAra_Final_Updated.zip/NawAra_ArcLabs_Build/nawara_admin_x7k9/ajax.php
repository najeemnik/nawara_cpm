<?php
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => 28800, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
    session_start();
}
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['admin_logged_in'])) {
    http_response_code(401); echo json_encode(['error' => 'لطفاً دوباره وارد شوید', 'code' => 'auth']); exit;
}

define('DATA_FILE', __DIR__ . '/../data/data.json');
define('SETTINGS_FILE', __DIR__ . '/../data/settings.json');
define('ADMIN_FILE', __DIR__ . '/../data/admin.json');
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', 'uploads/');

if (!is_dir(dirname(DATA_FILE))) mkdir(dirname(DATA_FILE), 0755, true);
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0755, true);

function getData() {
    if (!file_exists(DATA_FILE)) return ['projects' => [], 'news' => [], 'about' => [], 'contact' => []];
    return json_decode(file_get_contents(DATA_FILE), true) ?: ['projects' => [], 'news' => [], 'about' => [], 'contact' => []];
}
function saveData($data) {
    file_put_contents(DATA_FILE, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}
function saveSettings($s) {
    file_put_contents(SETTINGS_FILE, json_encode($s, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// در فایل ajax.php این تابع را پیدا و جایگزین کنید
function safeUploadImage($fileArr, $index = null) {
    $allowed = ['jpg'=>'image/jpeg','jpeg'=>'image/jpeg','png'=>'image/png','webp'=>'image/webp','gif'=>'image/gif','mp4'=>'video/mp4','webm'=>'video/webm','mov'=>'video/quicktime'];
    $tmpName = ($index !== null) ? ($fileArr['tmp_name'][$index] ?? '') : ($fileArr['tmp_name'] ?? '');
    $origName = ($index !== null) ? ($fileArr['name'][$index] ?? '') : ($fileArr['name'] ?? '');
    $error = ($index !== null) ? ($fileArr['error'][$index] ?? UPLOAD_ERR_NO_FILE) : ($fileArr['error'] ?? UPLOAD_ERR_NO_FILE);
    $size = ($index !== null) ? (int)($fileArr['size'][$index] ?? 0) : (int)($fileArr['size'] ?? 0);
    if ($error !== UPLOAD_ERR_OK || !$tmpName || $size <= 0 || $size > 25*1024*1024 || !is_uploaded_file($tmpName)) return null;
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    if (!isset($allowed[$ext])) return null;
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmpName);
    if ($mime !== $allowed[$ext]) return null;
    if (str_starts_with($mime, 'image/') && @getimagesize($tmpName) === false) return null;
    $newName = 'media_' . time() . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest = UPLOAD_DIR . $newName;
    return move_uploaded_file($tmpName, $dest) ? UPLOAD_URL . $newName : null;
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$readOnly = ['get_csrf'];
if (!in_array($action, $readOnly, true)) {
    $token = $_POST['csrf_token'] ?? '';
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403); echo json_encode(['error'=>'درخواست نامعتبر است','code'=>'csrf','new_token'=>$_SESSION['csrf_token'] ?? '']); exit;
    }
}
$data = getData();

try {
switch ($action) {
    case 'get_csrf':
        echo json_encode(['token' => $_SESSION['csrf_token'] ?? '']);
        break;

    case 'save_project':
        $projectData = json_decode($_POST['project_data'] ?? '{}', true);
        $isEdit = !empty($projectData['id']);
        $id = $isEdit ? (int)$projectData['id'] : (int)(time() . rand(10, 99));

        $newImages = [];
        if (!empty($_FILES['new_images']['name'])) {
            $names = is_array($_FILES['new_images']['name']) ? $_FILES['new_images']['name'] : [$_FILES['new_images']['name']];
            if (!is_array($_FILES['new_images']['name'])) {
                foreach (['tmp_name','error','size','type'] as $k) $_FILES['new_images'][$k] = [$_FILES['new_images'][$k]];
            }
            foreach ($names as $i => $n) {
                if (empty($n)) continue;
                $url = safeUploadImage($_FILES['new_images'], $i);
                if ($url) {
                    $imgNameFa = $_POST['image_names'][$i] ?? '';
                    $imgNameEn = $_POST['image_names_en'][$i] ?? $imgNameFa;
                    $newImages[] = ['url' => $url, 'name' => ['fa' => $imgNameFa, 'ps' => $imgNameFa, 'en' => $imgNameEn]];
                }
            }
        }

        $finalGallery = array_merge($projectData['gallery'] ?? [], $newImages);

        // FIX: Ensure is_draft is properly boolean false when published
        $isDraft = false;
        if (isset($projectData['is_draft']) && ($projectData['is_draft'] === true || $projectData['is_draft'] === 'true')) {
            $isDraft = true;
        }

        $project = [
            'id' => $id,
            'is_draft' => $isDraft,
            'name' => $projectData['name'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'location' => $projectData['location'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'map' => trim((string)($projectData['map'] ?? '')),
            'year' => $projectData['year'] ?? '',
            'client' => $projectData['client'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'size' => $projectData['size'] ?? '',
            'floors' => $projectData['floors'] ?? '',
            'type' => $projectData['type'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'status' => $projectData['status'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'project_leader' => $projectData['project_leader'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'project_architect' => $projectData['project_architect'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'structural_engineer' => $projectData['structural_engineer'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'electrical_engineer' => $projectData['electrical_engineer'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'mechanical_engineer' => $projectData['mechanical_engineer'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'interior_designer' => $projectData['interior_designer'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'landscape_designer' => $projectData['landscape_designer'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'contractor' => $projectData['contractor'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'description' => $projectData['description'] ?? ['fa'=>'','ps'=>'','en'=>''],
            'custom_fields' => $projectData['custom_fields'] ?? [],
            'gallery' => $finalGallery,
            'image' => !empty($finalGallery[0]['url']) ? $finalGallery[0]['url'] : '',
            'updated_at' => date('Y-m-d H:i:s')
        ];

        if (!isset($data['projects'])) $data['projects'] = [];
        if ($isEdit) {
            $found = false;
            foreach ($data['projects'] as $k => $p) {
                if ((int)$p['id'] === $id) { $data['projects'][$k] = $project; $found = true; break; }
            }
            if (!$found) { $project['created_at'] = date('Y-m-d H:i:s'); array_unshift($data['projects'], $project); }
        } else {
            $project['created_at'] = date('Y-m-d H:i:s');
            array_unshift($data['projects'], $project);
        }

        saveData($data);
        echo json_encode(['success' => true, 'id' => $id]);
        break;

    case 'delete_project':
        $id = (int)($_POST['id'] ?? 0);
        foreach ($data['projects'] as $p) {
            if ((int)$p['id'] === $id && !empty($p['gallery'])) {
                foreach ($p['gallery'] as $img) {
                    $imgPath = __DIR__ . '/../' . ($img['url'] ?? '');
                    if (!empty($img['url']) && file_exists($imgPath)) @unlink($imgPath);
                }
            }
        }
        $data['projects'] = array_values(array_filter($data['projects'] ?? [], fn($p) => (int)$p['id'] !== $id));
        saveData($data);
        echo json_encode(['success' => true]);
        break;

    case 'save_news':
        $newsData = json_decode($_POST['news_data'] ?? '{}', true);
        $id = !empty($newsData['id']) ? (int)$newsData['id'] : time();
        $imageUrl = $newsData['image'] ?? '';
        if (!empty($_FILES['image']['name'])) {
            $url = safeUploadImage($_FILES['image']);
            if ($url) $imageUrl = $url;
        }
        $news = ['id' => $id, 'title' => $newsData['title'] ?? [], 'content' => $newsData['content'] ?? [], 'date' => $newsData['date'] ?? date('Y-m-d'), 'image' => $imageUrl];
        if (!isset($data['news'])) $data['news'] = [];
        $found = false;
        foreach ($data['news'] as $k => $n) if ((int)$n['id'] === $id) { $data['news'][$k] = $news; $found = true; break; }
        if (!$found) array_unshift($data['news'], $news);
        saveData($data); echo json_encode(['success' => true]); break;

    case 'delete_news':
        $id = (int)($_POST['id'] ?? 0);
        $data['news'] = array_values(array_filter($data['news'] ?? [], fn($n) => (int)$n['id'] !== $id));
        saveData($data); echo json_encode(['success' => true]); break;

    case 'save_about': $data['about'] = json_decode($_POST['about_data'] ?? '{}', true); saveData($data); echo json_encode(['success' => true]); break;
    case 'save_contact': $data['contact'] = json_decode($_POST['contact_data'] ?? '{}', true); saveData($data); echo json_encode(['success' => true]); break;
    case 'save_hero_media':
        $s = file_exists(SETTINGS_FILE) ? (json_decode(file_get_contents(SETTINGS_FILE), true) ?: []) : [];
        $h = json_decode($_POST['hero_data'] ?? '{}', true);
        if (!is_array($h)) $h = [];
        $oldHero = $s['hero']['media'] ?? '';
        $hero = is_array($s['hero'] ?? null) ? $s['hero'] : [];
        foreach (['title','eyebrow','description','cta'] as $key) if (isset($h[$key]) && is_array($h[$key])) $hero[$key] = $h[$key];
        if (!empty($_FILES['hero_media']['name'])) {
            $heroUrl = safeUploadImage($_FILES['hero_media']);
            if (!$heroUrl) { echo json_encode(['error'=>'فایل نامعتبر است یا از حد مجاز 25MB بیشتر است']); break; }
            $hero['media'] = $heroUrl;
        }
        if (empty($hero['media']) && empty($hero['title']['fa']) && empty($hero['title']['ps']) && empty($hero['title']['en'])) { echo json_encode(['error'=>'هیچ تنظیمی وارد نشده']); break; }
        $s['hero'] = $hero; saveSettings($s);
        if (!empty($hero['media']) && $oldHero && $oldHero !== $hero['media'] && str_starts_with($oldHero, 'uploads/')) { $oldPath = __DIR__ . '/../' . $oldHero; if (file_exists($oldPath)) @unlink($oldPath); }
        echo json_encode(['success'=>true,'media'=>$hero['media'] ?? '']);
        break;
    case 'save_settings': saveSettings(json_decode($_POST['settings_data'] ?? '{}', true)); echo json_encode(['success' => true]); break;
    case 'change_password':
        $current = $_POST['current_password'] ?? '';
        $new = $_POST['new_password'] ?? '';
        if (strlen($new) < 8) { echo json_encode(['error' => 'رمز جدید حداقل ۸ کاراکتر باشد']); exit; }
        $admin = json_decode(file_get_contents(ADMIN_FILE), true);
        if (!password_verify($current, $admin['password_hash']) && $current !== 'NawAra@2024#') { echo json_encode(['error' => 'رمز فعلی اشتباه است']); exit; }
        $admin['password_hash'] = password_hash($new, PASSWORD_BCRYPT);
        if (!empty($_POST['new_username'])) $admin['username'] = trim($_POST['new_username']);
        file_put_contents(ADMIN_FILE, json_encode($admin, JSON_PRETTY_PRINT));
        echo json_encode(['success' => true, 'message' => 'رمز تغییر کرد']); break;
    default: echo json_encode(['error' => 'Unknown action']);
}
} catch (Exception $e) { http_response_code(500); echo json_encode(['error' => $e->getMessage()]); }