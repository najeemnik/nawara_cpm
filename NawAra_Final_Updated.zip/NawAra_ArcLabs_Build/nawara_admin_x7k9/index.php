<?php
// رفع مشکل سشن در هاست رایگان
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime' => 28800, 'path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
}

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');

define('ADMIN_FILE', __DIR__ . '/../data/admin.json');

if (!file_exists(ADMIN_FILE)) {
    if (!is_dir(dirname(ADMIN_FILE))) mkdir(dirname(ADMIN_FILE), 0755, true);
    http_response_code(500); die('Admin configuration missing.');
}

$admin = json_decode(file_get_contents(ADMIN_FILE), true);

if (!empty($_SESSION['admin_logged_in'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['csrf_token']) || !hash_equals($_SESSION['login_csrf'] ?? '', $_POST['csrf_token'])) { $error='درخواست نامعتبر است.'; } else {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $validPass = false;
    if (!empty($admin['password_hash']) && password_verify($password, $admin['password_hash'])) {
        $validPass = true;
    }

    if ($username === $admin['username'] && $validPass) {
        session_regenerate_id(true);
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'نام کاربری یا رمز عبور اشتباه است!';
        sleep(1);
    }
    }
}
if (empty($_SESSION['login_csrf'])) $_SESSION['login_csrf'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NawAra Studio - Admin Login</title>
<meta name="robots" content="noindex, nofollow">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family: 'Vazirmatn', sans-serif; background: #0a0a0a; color: white; min-height: 100vh; display: flex; align-items: center; justify-content: center; overflow: hidden; position: relative; }
body::before, body::after { content: ''; position: absolute; border-radius: 50%; filter: blur(100px); }
body::before { width: 500px; height: 500px; background: radial-gradient(circle, rgba(201,169,97,0.3), transparent); top: -150px; left: -100px; }
body::after { width: 400px; height: 400px; background: radial-gradient(circle, rgba(100,120,200,0.2), transparent); bottom: -100px; right: -100px; }
.card { background: rgba(20,20,20,0.7); backdrop-filter: blur(30px); border: 1px solid rgba(255,255,255,0.08); padding: 50px 45px; border-radius: 20px; width: 100%; max-width: 420px; position: relative; z-index: 1; }
.logo { width: 60px; height: 60px; background: linear-gradient(135deg, #c9a961, #8b7340); border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 28px; font-weight: 700; color: #0a0a0a; margin: 0 auto 20px; font-family: 'Inter', sans-serif; }
h1 { text-align: center; font-size: 22px; margin-bottom: 6px; }
.subtitle { text-align: center; color: #a0a0a0; font-size: 12px; letter-spacing: 3px; margin-bottom: 40px; }
label { display: block; font-size: 11px; color: #a0a0a0; letter-spacing: 2px; margin-bottom: 8px; text-transform: uppercase; }
input { width: 100%; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); color: white; padding: 14px 18px; border-radius: 10px; font-size: 14px; font-family: inherit; margin-bottom: 20px; }
input:focus { outline: none; border-color: #c9a961; }
button { width: 100%; background: #c9a961; color: #0a0a0a; border: none; padding: 15px; border-radius: 10px; font-size: 13px; font-weight: 700; letter-spacing: 3px; cursor: pointer; font-family: inherit; margin-top: 10px; }
button:hover { background: #d4b46c; }
.error { background: rgba(220,50,50,0.15); border: 1px solid rgba(220,50,50,0.3); color: #ff6b6b; padding: 12px; border-radius: 8px; font-size: 13px; text-align: center; margin-bottom: 20px; }
.info { text-align: center; color: #666; font-size: 11px; margin-top: 25px; }
</style>
</head>
<body>
<div class="card">
  <div class="logo">N</div>
  <h1>NawAra Studio</h1>
  <p class="subtitle">ADMIN PANEL</p>
  <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
  <form method="POST" autocomplete="off"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['login_csrf'], ENT_QUOTES, 'UTF-8') ?>">
    <label>نام کاربری</label><input type="text" name="username" required>
    <label>رمز عبور</label><input type="password" name="password" required>
    <button type="submit">ورود به سیستم</button>
  </form>
  <p class="info">🔒 Encrypted & Secure Connection</p>
</div>
</body>
</html>