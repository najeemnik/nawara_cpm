<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || !$_SESSION['admin_logged_in']) {
    die('Unauthorized');
}

$projectJson = $_POST['preview_data'] ?? '';
$project = json_decode($projectJson, true);
$lang = $_GET['lang'] ?? 'fa';
$dir = ($lang === 'en') ? 'ltr' : 'rtl';

function val($field, $lang) {
    if (is_array($field)) return $field[$lang] ?? '';
    return $field ?? '';
}
function has($field, $lang = null) {
    if ($lang === null) return !empty($field);
    if (is_array($field)) return !empty(trim($field[$lang] ?? ''));
    return !empty(trim($field));
}
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>" dir="<?= $dir ?>">
<head>
<meta charset="UTF-8">
<title>Preview - <?= htmlspecialchars(val($project['name'] ?? [], $lang)) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body {
  font-family: <?= $lang==='en'?"'Inter'":"'Vazirmatn'" ?>, sans-serif;
  background: #0a0a0a;
  color: white;
  padding: 40px;
}
.preview-badge {
  position: fixed;
  top: 20px;
  <?= $dir==='rtl'?'left':'right' ?>: 20px;
  background: #c9a961;
  color: #0a0a0a;
  padding: 10px 20px;
  border-radius: 50px;
  font-weight: 700;
  font-size: 12px;
  letter-spacing: 2px;
  z-index: 100;
}
.container { max-width: 900px; margin: 0 auto; }
h1 { font-size: 48px; font-weight: 400; margin-bottom: 10px; }
.location { color: #a0a0a0; font-size: 13px; letter-spacing: 2px; text-transform: uppercase; margin-bottom: 40px; }
.hero-img { width: 100%; aspect-ratio: 16/10; background-size: cover; background-position: center; border-radius: 12px; margin-bottom: 40px; background-color: #222; }
.meta-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 25px; padding: 30px 0; border-top: 1px solid rgba(255,255,255,0.1); border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 30px; }
.meta-item .label { font-size: 11px; color: #a0a0a0; letter-spacing: 2px; margin-bottom: 6px; text-transform: uppercase; }
.meta-item .value { font-size: 15px; }
.description { line-height: 1.9; color: #cfcfcf; margin-bottom: 40px; }
.section-title { font-size: 14px; color: #c9a961; letter-spacing: 3px; margin: 40px 0 20px; text-transform: uppercase; }
.gallery { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 15px; }
.gallery-item { aspect-ratio: 4/3; background-size: cover; background-position: center; border-radius: 8px; position: relative; overflow: hidden; }
.gallery-item .caption { position: absolute; bottom: 0; left: 0; right: 0; padding: 10px; background: linear-gradient(transparent, rgba(0,0,0,0.8)); font-size: 12px; }
.lang-switch { position: fixed; bottom: 20px; <?= $dir==='rtl'?'left':'right' ?>: 20px; background: #222; padding: 8px; border-radius: 50px; z-index: 100; }
.lang-switch button { background: none; border: none; color: #a0a0a0; padding: 6px 14px; border-radius: 50px; cursor: pointer; font-family: inherit; }
.lang-switch button.active { background: #c9a961; color: #0a0a0a; }
</style>
</head>
<body>

<div class="preview-badge">🔍 PREVIEW MODE</div>

<div class="container">

<?php if (has($project['image'] ?? '')): ?>
  <div class="hero-img" style="background-image:url('../<?= htmlspecialchars($project['image']) ?>')"></div>
<?php endif; ?>

<?php if (has($project['name'] ?? [], $lang)): ?>
  <h1><?= htmlspecialchars(val($project['name'], $lang)) ?></h1>
<?php endif; ?>

<?php if (has($project['location'] ?? [], $lang)): ?>
  <p class="location"><?= htmlspecialchars(val($project['location'], $lang)) ?></p>
<?php endif; ?>

<?php
$metaFields = [
    'year' => ['fa'=>'سال','ps'=>'کال','en'=>'Year'],
    'client' => ['fa'=>'کارفرما','ps'=>'ګاهک','en'=>'Client'],
    'size' => ['fa'=>'مساحت زمین','ps'=>'د ځمکې مساحت','en'=>'Site Area'],
    'floors' => ['fa'=>'تعداد طبقات','ps'=>'د پوړونو شمېر','en'=>'Floors'],
    'type' => ['fa'=>'نوع پروژه','ps'=>'د پروژې ډول','en'=>'Project Type'],
    'status' => ['fa'=>'وضعیت','ps'=>'حالت','en'=>'Status']
];

$hasAnyMeta = false;
foreach ($metaFields as $f => $lbls) {
    if (isset($project[$f]) && has($project[$f], is_array($project[$f]) ? $lang : null)) {
        $hasAnyMeta = true; break;
    }
}
?>

<?php if ($hasAnyMeta): ?>
<div class="meta-grid">
  <?php foreach ($metaFields as $f => $lbls): ?>
    <?php 
    $v = $project[$f] ?? '';
    $displayVal = is_array($v) ? val($v, $lang) : $v;
    if (has($displayVal)): 
    ?>
      <div class="meta-item">
        <div class="label"><?= $lbls[$lang] ?></div>
        <div class="value"><?= htmlspecialchars($displayVal) ?></div>
      </div>
    <?php endif; ?>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if (has($project['description'] ?? [], $lang)): ?>
  <p class="description"><?= nl2br(htmlspecialchars(val($project['description'], $lang))) ?></p>
<?php endif; ?>

<?php
$teamFields = [
    'project_leader' => ['fa'=>'رهبر پروژه','ps'=>'د پروژې رهبر','en'=>'Project Leader'],
    'project_architect' => ['fa'=>'مهندس پروژه','ps'=>'د پروژې انجنیر','en'=>'Project Architect'],
    'structural_engineer' => ['fa'=>'مهندس ساختمان','ps'=>'د جوړښت انجنیر','en'=>'Structural Engineer'],
    'electrical_engineer' => ['fa'=>'مهندس برق','ps'=>'د برېښنا انجنیر','en'=>'Electrical Engineer'],
    'mechanical_engineer' => ['fa'=>'مهندس مکانیک','ps'=>'د مکانیک انجنیر','en'=>'Mechanical Engineer'],
    'interior_designer' => ['fa'=>'طراح داخلی','ps'=>'د داخلي ډیزاینر','en'=>'Interior Designer'],
    'landscape_designer' => ['fa'=>'طراح محوطه','ps'=>'د منظرې ډیزاینر','en'=>'Landscape Designer'],
    'contractor' => ['fa'=>'پیمانکار','ps'=>'قراردادي','en'=>'Contractor']
];

$hasTeam = false;
foreach ($teamFields as $f => $l) if (has($project[$f] ?? [], $lang)) { $hasTeam = true; break; }
?>

<?php if ($hasTeam): ?>
  <div class="section-title"><?= $lang==='fa'?'تیم پروژه':($lang==='ps'?'د پروژې ټیم':'PROJECT TEAM') ?></div>
  <div class="meta-grid" style="border:none;padding:0;">
    <?php foreach ($teamFields as $f => $lbls): ?>
      <?php if (has($project[$f] ?? [], $lang)): ?>
        <div class="meta-item">
          <div class="label"><?= $lbls[$lang] ?></div>
          <div class="value"><?= htmlspecialchars(val($project[$f], $lang)) ?></div>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php if (!empty($project['custom_fields'])): ?>
  <div class="section-title"><?= $lang==='fa'?'اطلاعات اضافی':($lang==='ps'?'اضافي معلومات':'ADDITIONAL INFO') ?></div>
  <div class="meta-grid" style="border:none;padding:0;">
    <?php foreach ($project['custom_fields'] as $cf): ?>
      <?php if (has($cf['value'] ?? [], $lang)): ?>
        <div class="meta-item">
          <div class="label"><?= htmlspecialchars(val($cf['label'] ?? [], $lang)) ?></div>
          <div class="value"><?= htmlspecialchars(val($cf['value'], $lang)) ?></div>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php if (!empty($project['gallery'])): ?>
  <div class="section-title"><?= $lang==='fa'?'گالری تصاویر':($lang==='ps'?'د انځورونو ګالري':'GALLERY') ?></div>
  <div class="gallery">
    <?php foreach ($project['gallery'] as $img): ?>
      <div class="gallery-item" style="background-image:url('../<?= htmlspecialchars($img['url']) ?>')">
        <?php if (has($img['name'] ?? [], $lang)): ?>
          <div class="caption"><?= htmlspecialchars(val($img['name'], $lang)) ?></div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

</div>

<div class="lang-switch">
  <button class="<?= $lang==='fa'?'active':'' ?>" onclick="switchLang('fa')">فا</button>
  <button class="<?= $lang==='ps'?'active':'' ?>" onclick="switchLang('ps')">پښتو</button>
  <button class="<?= $lang==='en'?'active':'' ?>" onclick="switchLang('en')">EN</button>
</div>

<script>
function switchLang(l) {
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = 'preview.php?lang=' + l;
  const input = document.createElement('input');
  input.type = 'hidden';
  input.name = 'preview_data';
  input.value = <?= json_encode($projectJson) ?>;
  form.appendChild(input);
  document.body.appendChild(form);
  form.submit();
}
</script>
</body>
</html>